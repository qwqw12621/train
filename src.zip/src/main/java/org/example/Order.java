package org.example;

import java.time.LocalDateTime;
import java.util.UUID;

public class Order {
    private final String id;
    private final String traceId; // 追蹤用
    private final String customerName;
    private final String restaurantName;
    private OrderStatus status;
    private final LocalDateTime createdAt;

    public Order(String customerName, String restaurantName) {
        this.id = UUID.randomUUID().toString();
        this.traceId = UUID.randomUUID().toString();
        this.customerName = customerName;
        this.restaurantName = restaurantName;
        this.status = OrderStatus.PENDING;
        this.createdAt = LocalDateTime.now();
    }

    public String getId() { return id; }
    public String getTraceId() { return traceId; }
    public String getCustomerName() { return customerName; }
    public String getRestaurantName() { return restaurantName; }
    public OrderStatus getStatus() { return status; }
    public void setStatus(OrderStatus status) { this.status = status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}