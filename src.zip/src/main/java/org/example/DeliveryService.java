package org.example;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DeliveryService {
    private static final Logger logger = LogManager.getLogger(DeliveryService.class);
    private final OrderService orderService;

    public DeliveryService(OrderService orderService) { this.orderService = orderService; }

    public void pickupOrder(Order order) {
        if (order == null) { logger.error("pickupOrder called with null order"); throw new InvalidOrderRuntimeException("Order is null"); }
        logger.info("DeliveryService try pickup order {}", order.getId());
        switch (order.getStatus()) {
            case READY_FOR_PICKUP:
            case ACCEPTED:
                try {
                    orderService.transition(order, OrderStatus.PICKED_UP);
                    logger.info("Order {} picked up by delivery.", order.getId());
                } catch (OrderProcessingException e) {
                    logger.error("Failed to transition to PICKED_UP: {}", e.getMessage(), e);
                    throw new InvalidOrderRuntimeException("Illegal pickup state: " + order.getStatus(), e);
                }
                break;
            default:
                logger.warn("Order {} is not ready for pickup (status={})", order.getId(), order.getStatus());
        }
    }

    public void deliverOrder(Order order) {
        if (order == null) { logger.error("deliverOrder called with null order"); throw new InvalidOrderRuntimeException("Order is null"); }
        logger.info("Delivering order {}", order.getId());
        try {
            orderService.transition(order, OrderStatus.DELIVERED);
            logger.info("Order {} delivered to {}", order.getId(), order.getCustomerName());
        } catch (OrderProcessingException e) {
            logger.error("Failed to transition to DELIVERED: {}", e.getMessage(), e);
            throw new InvalidOrderRuntimeException("Illegal deliver state: " + order.getStatus(), e);
        }
    }
}