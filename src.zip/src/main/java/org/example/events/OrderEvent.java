package org.example.events;

public interface OrderEvent {}