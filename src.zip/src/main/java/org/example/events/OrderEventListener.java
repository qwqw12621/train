package org.example.events;

public interface OrderEventListener {
    void onEvent(OrderEvent event);
}